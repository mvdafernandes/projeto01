create index if not exists idx_receitas_data on receitas(data);
create index if not exists idx_despesas_data on despesas(data);
create index if not exists idx_investimentos_data on investimentos(data);
